window.API_URL = 'https://www.dualcode.com.br/blsmart/api';
